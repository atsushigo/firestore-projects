export default { 
  apiKey: "AIzaSyBD9fVN9f7xF4NPsCS2lb1KAo5rFVU3C0w",
  authDomain: "vuefs-dev.firebaseapp.com",
  databaseURL: "https://vuefs-dev.firebaseio.com",
  projectId: "vuefs-dev",
  storageBucket: "",
  messagingSenderId: "622175178817"
}