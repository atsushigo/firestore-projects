 <template>
  <nav>
      <div class="nav-wrapper green">
        <div class="container">
          <router-link to="/" class="brand-logo">Employee Manager</router-link>    
        </div>
      </div>
    </nav>
  </template>